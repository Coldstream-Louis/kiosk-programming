/**
 * Created by dushuyang on 09/01/2018.
 */

var drinks = [
    {
        name:0,
        ingredient:0,
        priceS:0,
        priceM:0,
        priceL:0,
    },
    {
        name:'Pineapple juice',
        ingredient:[2,19,9,10],
        priceS:30,
        priceM:40,
        priceL:50,
    },
    {
        name:'Tomato juice',
        ingredient:[53,5,12,8],
        priceS:25,
        priceM:35,
        priceL:45,
    },
    {
        name:'Green juice',
        ingredient:[1,48,51,43],
        priceS:30,
        priceM:40,
        priceL:50,
    },
    {
        name:'Grand juice',
        ingredient:[2,19,9,10],
        priceS:25,
        priceM:35,
        priceL:40,
    },
];
